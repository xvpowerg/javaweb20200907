package tw.com.mod;

public class Utils {
    private static String imagePath;
    
    public static void setImagePath(String imagePath) {
    	Utils.imagePath = imagePath;
    }
    public static String getImagePath() {
    	return imagePath;
    }
}
