package tw.com.wsocket;

import javax.websocket.OnMessage;
import javax.websocket.server.ServerEndpoint;

@ServerEndpoint("/echo")
public class EchoServer {
	
	@OnMessage
	public String message(String message) {
		message = message.toUpperCase();
		return "OK!!"+message;
	}
}
