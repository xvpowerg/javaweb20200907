package tw.com.ws;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("test")
@Produces(MediaType.APPLICATION_JSON)
public class TestRestful {
	//GET �ΨӰ��d�� ���|�׸Ӹ��
	//POST �Ψӷs�W���
	//PATCH �i�Ψӭק���
	//DELETE �ΨӧR�����
	//JSON
	@GET
	public String testHello() {
		return "{\"value\":\"�A�n!!\"}";
	}
	
	@GET
	@Path("hello2")
	public String testHello2() {
		return "{\"value\":\"�A�n2!!\"}";
	}
	
	//{} ���ܧڭn�^��������
	@GET
	@Path("/id/{myId:\\S+}")
	public String testId(@PathParam("myId") String myId) {
		return "{\"myId\":\""+myId+"\"}";
	}
	
	@POST
	public String login(@FormParam("account") String account,
			@FormParam("password") String password) {
		String json = String.format("{\"account\":\"%s\","
					+ "\"password\":\"%s\"}", account,password);
		//{"account" :"Ken","password":"12345"}
		return json;
	}
	
}
