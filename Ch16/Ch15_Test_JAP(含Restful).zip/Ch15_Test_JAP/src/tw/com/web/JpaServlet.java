package tw.com.web;

import java.io.IOException;

import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import tw.com.entity.MyUser;
import tw.com.sbean.MyUserBeanLocal;
@WebServlet("/JpaServlet")
public class JpaServlet extends HttpServlet {
	//@EJB �n�ϥ�Session Bean
	@EJB
	private MyUserBeanLocal myUserBean;
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
			MyUser myUser = new MyUser();
			myUser.setAccount("Ken");
			myUser.setPassword("12345");
		    myUserBean.createUser(myUser);
		    
		    MyUser myUser2 =  myUserBean.findMyUser("Ken", "12345");
		    System.out.println(myUser2);

	}
}
