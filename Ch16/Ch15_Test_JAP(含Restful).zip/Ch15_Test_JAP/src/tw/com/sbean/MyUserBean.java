package tw.com.sbean;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import tw.com.entity.MyUser;

/**
 * Session Bean implementation class MyUserBean
 */
@Stateless
public class MyUserBean implements MyUserBeanLocal {
	//����g�J��Ʈw
	//em.persist(arg0);
	//�i�H���� �����O ��EntityManager �������Y
	//em.detach(arg0);
	//�i�H���� �o�~�O�Ѹ�Ʈw����
	//em.remove(arg0);
	//�i��s 
	//em.merge(arg0)
	//�i�d��
	//em.createNamedQuery(arg0)
	
	
	@Inject
	private EntityManager em;
    /**
     * Default constructor. 
     */
    public MyUserBean() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public boolean createUser(MyUser myUser) {
		// TODO Auto-generated method stub
		try {
			em.persist(myUser);
		}catch(Exception ex) {
			System.out.println("createUser:"+ex);
			return false;
		}
		return true;
	}

	@Override
	public MyUser findMyUser(String account, String password) {
		// TODO Auto-generated method stub
				//createNamedQuery �Ѽ�1 
		TypedQuery<MyUser> query = 
				em.createNamedQuery("findMyUser", MyUser.class);	
		query.setParameter("account", account);
		//�h����
		//query.getResultList();
		MyUser myUser = query.getSingleResult();		
		return myUser.getPassword().equals(password)? myUser:null;
	}

}
