package tw.com.sbean;

import javax.ejb.Local;

import tw.com.entity.MyUser;

@Local
public interface MyUserBeanLocal {
		boolean createUser(MyUser myUser);
		MyUser findMyUser(String account,String password);
}
