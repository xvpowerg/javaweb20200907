package tw.com.web;

public interface Product {
	public void setPrice(int price);
	public void setName(String name);
	public int getPrice();
	public String getName();
}
