package tw.com.db;

import tw.com.bean.DBInfo;

public class DaoFactory {
	
	public static UserDao factoryUserDao() {
		switch(DBInfo.getSqltype()) {
			case MYSQL:
				return new MySqlUserDao();
			}
		
		return null;
	}
}
