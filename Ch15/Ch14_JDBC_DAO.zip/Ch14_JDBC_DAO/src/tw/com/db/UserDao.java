package tw.com.db;

import tw.com.bean.MyUser;

public interface UserDao {
	
	int createUser(String account,String password);
	MyUser queryUser(String account,String password);
    
   default MyUser login(String account,String password) {
	   MyUser myUser = queryUser(account,password);	   
	   return myUser;
   }
   
}
