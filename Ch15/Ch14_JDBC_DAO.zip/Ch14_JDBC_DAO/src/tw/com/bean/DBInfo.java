package tw.com.bean;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class DBInfo {
	private static String url;
	private static String password;
	private static String account;
	private static SqlType sqltype;
	public enum SqlType{
		MYSQL,
		MSSQL,
		ORACLE
	}
	
	public static String getUrl() {		
		return url;
	}
	public static void setUrl(String url) {
		DBInfo.url = url;
	}
	public static String getPassword() {
		return password;
	}
	public static void setPassword(String password) {
		DBInfo.password = password;
	}
	public static String getAccount() {
		return account;
	}
	public static void setAccount(String account) {
		DBInfo.account = account;
	}
	
	public static SqlType getSqltype() {
		return sqltype;
	}
	public static void setSqltype(String sqltype) {
		DBInfo.sqltype = SqlType.valueOf(sqltype);
	}
	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url,account,password);
	}
	
}
