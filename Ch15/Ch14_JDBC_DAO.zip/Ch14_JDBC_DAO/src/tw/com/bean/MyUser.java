package tw.com.bean;

public class MyUser {
	private String account;
	private String password;
	public MyUser(String account, String password) {
		super();
		this.account = account;
		this.password = password;
	}
	public String getAccount() {
		return account;
	}
	public String getPassword() {
		return password;
	}
	
	
}
