package tw.com.web;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import tw.com.bean.MyUser;
import tw.com.db.DaoFactory;
import tw.com.db.UserDao;
@WebServlet("/LoginServlet")
public class LoginServlet  extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String account = req.getParameter("account");
		String password = req.getParameter("password");
		 UserDao userDao =  DaoFactory.factoryUserDao();
		 MyUser myUser =   userDao.login(account, password);
		 HttpSession session =   req.getSession();
		 if (myUser != null) {			
			session.setAttribute("login", myUser);
			resp.sendRedirect("user/UserInfo.jsp");
		 }else {		
			 session.setAttribute("loginError", "Fail");
			 System.out.println("Fail!!");
			 resp.sendRedirect("Login.jsp");
		 }
	}
}
