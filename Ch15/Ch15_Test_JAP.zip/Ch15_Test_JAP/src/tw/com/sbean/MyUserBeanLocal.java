package tw.com.sbean;

import javax.ejb.Local;

import tw.com.entity.MyUser;

@Local
public interface MyUserBeanLocal {
		void createUser(MyUser myUser);
}
