package tw.com.error;

public class WebError {
	private String msg;

	public WebError(String msg) {
		super();
		this.msg = msg;
	}

	public String getMsg() {
		return msg;
	}
	
}
