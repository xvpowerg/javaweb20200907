package tw.com.bean;

public class MyUser {

}
