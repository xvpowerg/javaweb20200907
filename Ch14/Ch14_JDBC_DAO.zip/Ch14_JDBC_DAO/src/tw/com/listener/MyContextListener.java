package tw.com.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import tw.com.bean.DBInfo;

@WebListener
public class MyContextListener implements ServletContextListener {
	@Override
	public void contextInitialized(ServletContextEvent event) {
		String url = 
				event.getServletContext().getInitParameter("url");
		String name = 
				event.getServletContext().getInitParameter("name");		
		String password =
				event.getServletContext().getInitParameter("password");
		String sqltype =
				event.getServletContext().getInitParameter("sqltype");
		 DBInfo.setUrl(url);   
		 DBInfo.setAccount(name);
		 DBInfo.setPassword(password);
		 DBInfo.setSqltype(sqltype);
	}
	
}
