package tw.com.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.activemq.store.jdbc.adapter.MySqlJDBCAdapter;

import tw.com.db.DaoFactory;
import tw.com.db.MySqlUserDao;
import tw.com.db.UserDao;
import tw.com.error.WebError;
@WebServlet("/CreateUserServlet")
public class CreateUserServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		UserDao dao = DaoFactory.factoryUserDao();
		String account = req.getParameter("account");
		String password1 = req.getParameter("password1");
		String password2 = req.getParameter("password2");
		 List<WebError> webErrorList = new ArrayList<>();
		 HttpSession session =  req.getSession();
		 session.setAttribute("weberrors", webErrorList);
		 
		 
		if (!password1.equals(password2)) {			
			webErrorList.add(new WebError("�K�X���۵�"));
			resp.sendRedirect("CreateUser.jsp");
			return;
		}
		int count = dao.createUser(account,password1);
		System.out.println(count);
		
	}
}
