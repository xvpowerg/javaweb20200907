package tw.com.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import tw.com.bean.DBInfo;
import tw.com.bean.MyUser;

public class MySqlUserDao  implements UserDao{

	@Override
	public int createUser(String account, String password) {
		// TODO Auto-generated method stub
		int count = -1;
		String sql="INSERT INTO myuser (account,password) "
				+ "VALUES('%s','%s')";
			try(Connection con =  DBInfo.getConnection();
				Statement stem = con.createStatement();){	
				sql = String.format(sql,account,password);
				count = stem.executeUpdate(sql);				
			}catch(SQLException ex) {
				System.out.println(ex+":"+sql);
				return count;
			}
		
		return count;
	}

	@Override
	public MyUser queryUser(String account, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
