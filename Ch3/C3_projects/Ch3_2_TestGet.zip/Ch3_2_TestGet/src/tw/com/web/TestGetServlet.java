package tw.com.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/TestGetServlet")
public class TestGetServlet extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		 PrintWriter out =  resp.getWriter();
		 //getParameter �|�^�Ǧr��
		 //HttpServletRequest ����getParameter ���o�Ѽ�
		 //�p�G�Lnumber�Ѽ� �����
		String number =  req.getParameter("number");
	
		 if(number != null) {
			 out.println("TestGetServlet!"+number);
		 }
		 
		 String action =   req.getParameter("action");
		 String n1 =  req.getParameter("n1");
		 String n2 =  req.getParameter("n2");
		 
		 int ans = 0;
		 if (action!=null && n1 !=null && n2 != null) {
			 try {
				 int intN1 = Integer.parseInt(n1);
				 int intN2 = Integer.parseInt(n2);
				 
				 switch(action) {
					 case "add":
						 ans = intN1 + intN2;
						 break;
					 default:
					    throw new IllegalArgumentException("action Error!");
				 }	 
			 }catch(Exception ex) {
				 System.out.println("action:"+ex);
			 }
			
			 out.println("TestGetServlet!"+ans);
		 }

	}
}
